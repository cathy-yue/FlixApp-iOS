//
//  ViewController.swift
//  FlixApp
//
//  Created by james on 9/1/20.
//  Copyright © 2020 Cathy Yue. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

