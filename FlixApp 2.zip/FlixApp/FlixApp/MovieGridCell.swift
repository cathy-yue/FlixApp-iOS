//
//  MovieGridCell.swift
//  FlixApp
//
//  Created by james on 9/11/20.
//  Copyright © 2020 Cathy Yue. All rights reserved.
//

import UIKit

class MovieGridCell: UICollectionViewCell {
    
    @IBOutlet weak var posterView: UIImageView!
}
